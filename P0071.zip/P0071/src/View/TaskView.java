
package View;

public class TaskView {
    public void displayMess(String mess){
        System.out.println(mess);
    }
    public void displayToInput(String t){
        System.out.print(t);
    }
    
}
