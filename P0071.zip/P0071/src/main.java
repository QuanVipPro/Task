
import Controller.CCRMControl;
public class main {
    public static void main(String[] args) {
        CCRMControl sc = new CCRMControl();
        sc.run();
    }
}
